from django.shortcuts import render

# Create your views here.
from .models import LoginDetails
# Create your views here.
import operator
from django.http import HttpResponse
from django.http import HttpResponseRedirect

def login(requests):
    return render(requests,'app1/login.html')


def signup(requests):
    return render(requests,'app1/signup.html')


def signupsubmit(requests):
    try:
        email=requests.POST['email']
        passwd=requests.POST['password']
        LoginDetails.objects.create(email=email,password=passwd)
        return render(requests,'app1/login.html')
    except :
        return HttpResponseRedirect('invalid email id or password')

def logincheck(requests):
    email=requests.POST['email']
    passwd=requests.POST['password']
    try :
        a=LoginDetails.object.filter(email=email)
        if a.password==passwd :
            return render(requests,'app1/signup.html')
        else :
            return render(requests,'app1/login.html')
    except :
        return HttpResponseRedirect('invalid email id or password')